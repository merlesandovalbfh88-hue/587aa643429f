// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Commission device\n", stdout);
  return lionss_run_workload("matterCommission");
}
