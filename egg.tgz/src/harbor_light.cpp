// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Sweep harbor beacons\n", stdout);
  return lionss_run_workload("harbor_light");
}
