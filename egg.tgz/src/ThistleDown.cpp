// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Drift thistledown seeds\n", stdout);
  return lionss_run_workload("ThistleDown");
}
