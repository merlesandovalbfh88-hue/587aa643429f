// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Convert AsciiDoc to PDF\n", stdout);
  return lionss_run_workload("AsciidocPdf");
}
